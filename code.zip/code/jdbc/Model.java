package jdbc;
import java.sql.*;

public class Model {

	public static void listStudent(){
		//TODO
	}        
}